To use this component: 
-copy MaskComponent.css & .js to your src folder
-copy loading.png into public folder

-You need to include the following on your package.json
"dependencies": {
�react-bootstrap� : �^1.0.0-beta.5�,
�bootstrap�: �^4.3.1�,
}

-On your index.js file include:
import 'bootstrap/dist/css/bootstrap.min.css';

-Import the FormComponent for use:
import MaskComponent from "./MaskComponent";


