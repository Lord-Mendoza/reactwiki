To use this component: 
-copy MaskComponent.css & .js to your src folder
-copy loading.png into public folder

-You need to include the following on your package.json
"dependencies": {
	�react-bootstrap� : �latest�,
	�bootstrap�: �latest�,
}

-On your index.js file include:
import 'bootstrap/dist/css/bootstrap.min.css';

-Import the MaskComponent for use:
import MaskComponent from "./MaskComponent";


