To use this component: 
-copy FormFieldsComponent.js and .css to your src folder

-You need to include the following on your package.json
"dependencies": {
	�react-bootstrap� : �latest�,
	�bootstrap�: �latest�,
    �react-select� : �latest�,
    �react-datepicker� : �latest�,
    �moment� : �latest�,
    �semantic-ui-css� : �latest�,
    �semantic-ui-react�: �latest�
}

-On your index.js file include:
import 'bootstrap/dist/css/bootstrap.min.css'

-Import the FormFieldsComponent for use:
import FormFieldsComponent from './FormFieldsComponent'
