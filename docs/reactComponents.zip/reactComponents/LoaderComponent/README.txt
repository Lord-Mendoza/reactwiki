To use this component: 
-copy LoaderComponent.js to your src folder

-You need to include the following on your package.json
"dependencies": {
�semantic-ui-css� : �^2.4.1�,
�semantic-ui-react�: �^0.87.1�,
}

-Then on your index.js file include:
import 'semantic-ui-css/semantic.min.css';

-Lastly, import the LoaderComponent for use:
import LoaderComponent from "./LoaderComponent";
