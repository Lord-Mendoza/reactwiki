To use this component: 
-copy PopupComponent.js to your src folder

-You need to include the following on your package.json
"dependencies": {
�react-bootstrap� : �^1.0.0-beta.5�,
�bootstrap�: �^4.3.1�,
}

-On your index.js file include:
import 'bootstrap/dist/css/bootstrap.min.css'

-Import the FormComponent for use:
import PopupComponent from "./PopupComponent";

