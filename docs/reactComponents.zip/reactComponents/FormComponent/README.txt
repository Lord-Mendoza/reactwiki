To use this component: 
-copy FormComponent.js to your src folder

-You need to include the following on your package.json
"dependencies": {
	�react-bootstrap� : �latest�,
	�bootstrap�: �latest�,
}

-On your index.js file include:
import 'bootstrap/dist/css/bootstrap.min.css'

-Import the FormComponent for use:
import FormComponent from './FormComponent'
