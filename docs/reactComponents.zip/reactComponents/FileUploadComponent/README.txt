To use this component: 
-copy FileUploadComponent.js to your src folder

-You need to include the following on your package.json
"dependencies": {
�semantic-ui-css� : �^2.4.1�,
�semantic-ui-react�: �^0.87.1�,
�react-dropzone�: �^10.1.7�,
}

-Then on your index.js file include:
import 'semantic-ui-css/semantic.min.css';

-Add the upload.png file to the public folder. Note: you can put your own image on there, as long as its named "upload.png".

-Lastly, import the FileUploadComponent for use:
import FileUploadComponent from "./FileUploadComponent";
