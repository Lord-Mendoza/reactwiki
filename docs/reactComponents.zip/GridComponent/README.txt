To use this component: 
-copy GridComponent.css & .js to your src folder

-You need to include the following on your package.json
"dependencies": {
�@devexpress/dx-react-core� : �^1.10.1�,
�@devexpress/dx-react-grid� : �^1.10.1�,
�@devexpress/dx-react-grid-bootstrap4� : �^1.10.5�,
�bootstrap�: �^4.3.1�,
}

-On your index.js file include:
import 'bootstrap/dist/css/bootstrap.min.css'

-Import the FormComponent for use:
import GridComponent from "./GridComponent"

