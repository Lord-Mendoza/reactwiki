To use this component: 
-copy PopupComponent.js to your src folder

-You need to include the following on your package.json
"dependencies": {
	�react-bootstrap� : �latest�,
	�bootstrap�: �latest�,
	�react-icons�: �latest�,
}

-On your index.js file include:
import 'bootstrap/dist/css/bootstrap.min.css'

-Import the PopupComponent for use:
import PopupComponent from "./PopupComponent"

